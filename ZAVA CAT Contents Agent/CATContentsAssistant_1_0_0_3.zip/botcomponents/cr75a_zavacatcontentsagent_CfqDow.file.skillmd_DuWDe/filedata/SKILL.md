---
name: "zava-claim-valuation-export"
description: "Exports claim contents valuation data from Dataverse as a print-ready ZAVA Insurance Detail by Reference No PDF report. Use when the user requests a claim valuation export or ZAVA claim report. Do not use for editing Dataverse records or processing claim payments or approvals."
---
 
# ZAVA Claim Valuation Export
 
## Overview
Given any claim number, read that claim's inventory items and their valuations from Dataverse,
match them, and render a print-ready landscape **PDF** titled **"Detail by Reference No."**
branded **ZAVA Insurance**. All values come from Dataverse — never ask for an Excel file or an
upload. The only output is the PDF.
 
## Dataverse Mapping
 
### Inventory table
- **Entity set name:** `cca_inventoryitems`
- **Table logical name:** `cca_inventoryitem`
 
| Report field | Dataverse logical name | Rule |
|---|---|---|
| Claim ID | `cca_claimid` | Filter on the requested claim number |
| Ref | `cca_sourceitemreference` | Sort ascending; match with the valuation Ref |
| Room | `cca_room` | Room or category |
| Description | `cca_itemdescription` | Shown under Original Item |
| Brand | `cca_brand` | Appended to Description when available |
| Replacement Link | `cca_itemlocation` | Clickable Suggested Replacement link |
| Supplier | *(not mapped)* | Derived by the script from the link's website |
| Quantity | *(not mapped)* | Always `1` |
 
### Valuation table
- **Entity set name:** `cca_itemvaluations`
- **Table logical name:** `cca_itemvaluation`
 
| Report field | Dataverse logical name | Rule |
|---|---|---|
| Claim ID | `cca_claimid` | Must match the inventory Claim ID |
| Ref | `cca_sourceitemreference` | Must match the inventory Ref |
| RCV | `cca_replacementvalueeach` | Shown under RCV |
| Depreciation rate | `cca_depreciationpercent` | `0.3` and `30` both display as `30.00` in Rate % |
| Source ACV | `cca_acveach` | Used only to reconcile the calculated ACV |
 
### Claim header (optional — not configured)
No claim header table is configured. Use the requested claim number as the Claim value, always
show `ZAVA INSURANCE` as Insurer, and leave Type, Tax rate, Adjuster, Phone(s) and E-Mail(s)
blank. **This is not an error — continue and build the report.**
 
To add header values later, add a table here with its entity set name and the logical names for
claim number, type, tax rate, adjuster, phone and email. Any field left unmapped stays blank.
 
## Workflow
 
### Step 1: Identify the claim
Take the claim number from the request exactly as written. It can be any value, for example
`8`, `10`, `1042` or `CLM-2026-00457`. If no claim number is given, ask once:
"Which claim number should I export?"
 
### Step 2: Confirm the real column names (do this every run, before any query)
The logical names in the mapping tables are the **expected** names. Real names can differ, so
check them first:
 
1. Use the Dataverse describe/schema tool on `cca_inventoryitem` and on `cca_itemvaluation`
to list each table's actual columns (logical name + display name).
2. For each report field, use the configured logical name if it exists. If it does not, pick the
actual column whose **display name** matches the report field, using these display names:
- Ref → "Source Item Reference" (or "Item Reference", "Ref", "Reference")
- Room → "Room" (or "Category")
- Description → "Item Description" (or "Description")
- Brand → "Brand"
- Replacement Link → "Item Location", "Location", "Replacement Link" or "URL"
- Claim ID → "Claim ID" (or "Claim")
- RCV → "Replacement Value Each" (or "Replacement Value", "RCV")
- Depreciation → "Depreciation Percent" (or "Depreciation")
- Source ACV → "ACV Each" (or "ACV")
3. Use the **actual** logical names from the describe result in every `$select`, `$filter` and
`$orderby` below — never a name that the describe result did not return.
4. Only stop if a **required** field (Claim ID, Ref, Description, RCV, Depreciation) has
no matching column. Reply: "No Dataverse column was found for [report field] in [table].
Available columns: [list of display name (logical name)]. The ZAVA valuation report was not created."
Room, Brand and Replacement Link are optional: if no column matches, leave them blank and continue.
5. In the final reply, list the column mapping actually used, so it can be copied into this skill.
 
Unmapped optional fields (Supplier, Quantity, claim header) are **not** errors.
 
### Step 3: Read inventory records
List rows from `cca_inventoryitems` (replace each column below with the actual name confirmed in Step 2):
 
- `$select=cca_claimid,cca_sourceitemreference,cca_room,cca_itemdescription,cca_brand,cca_itemlocation`
- `$filter=cca_claimid eq '<claim>'` for a text column, or `cca_claimid eq <claim>` for a number column
- `$orderby=cca_sourceitemreference asc`
- Follow `@odata.nextLink` until all pages are read.
 
If no rows are returned, stop and reply:
 
"No inventory records were found for Claim [claim]. The ZAVA valuation report was not created."
 
### Step 4: Read valuation records
List rows from `cca_itemvaluations` (use the actual names confirmed in Step 2):
 
- `$select=cca_claimid,cca_sourceitemreference,cca_replacementvalueeach,cca_depreciationpercent,cca_acveach`
- the same `$filter` on `cca_claimid`; read all pages.
 
If no rows are returned, stop and reply:
 
"Inventory records were found for Claim [claim], but no completed valuation records were found. The ZAVA valuation report was not created."
 
### Step 5: Match inventory and valuation records
Match on **both** Claim ID and Ref, comparing them as trimmed text. Never match on Ref alone.
 
- More than one valuation row for the same Claim ID + Ref → stop:
"Duplicate valuation records were found for references: [refs]. The ZAVA valuation report was not created."
- Inventory rows without a valuation → collect all of them, then stop:
"The following inventory references do not have completed valuation records: [refs]. The ZAVA valuation report was not created."
- Never fill in zero for a missing RCV, depreciation or ACV.
 
### Step 6: Build the mapped JSON
Write `claim_<claim>.json`. Use plain numbers and plain URLs — no currency text, `%` signs,
`"N/A"`, HTML or Dataverse formatted values in numeric fields. Use `null` when a value is missing.
 
```json
{
"header": {
"claim": "8",
"type": null,
"tax_rate": null,
"adjuster": null,
"phones": null,
"emails": null
},
"items": [
{
"ref": 14,
"class": "Bedroom 1",
"description": "55-inch television",
"brand": "Samsung",
"replacement_link": "https://www.bestbuy.ca/example-product",
"replacement_name": null,
"supplier": null,
"qty": 1,
"unit": "EACH",
"unit_cost": null,
"rcv": 1400,
"depreciation": 0.3,
"acv": 980
}
]
}
```
 
| JSON property | Source |
|---|---|
| `header.claim` | Requested claim number |
| `header.type`, `tax_rate`, `adjuster`, `phones`, `emails` | `null` (no header table configured) |
| `items[].ref` | Inventory `cca_sourceitemreference` |
| `items[].class` | Inventory `cca_room`; displayed as Room in the PDF |
| `items[].description` | Inventory `cca_itemdescription` |
| `items[].brand` | Inventory `cca_brand` |
| `items[].replacement_link` | Inventory `cca_itemlocation` |
| `items[].replacement_name` | `null` |
| `items[].supplier` | `null` (the script derives it from the link) |
| `items[].qty` / `unit` | `1` / `"EACH"`; the PDF displays only `1` |
| `items[].unit_cost` | `null` (the script calculates it internally but does not display it) |
| `items[].rcv` | Valuation `cca_replacementvalueeach` |
| `items[].depreciation` | Valuation `cca_depreciationpercent` |
| `items[].acv` | Valuation `cca_acveach` |
 
For the output file name, replace any of `/ \ : * ? " < > |` in the claim number with `-`.
 
### Step 7: Render the PDF (compute with code, never by hand)
 
```bash
python scripts/build_zava_pdf.py --input claim_<n>.json \
--output Claim_<n>_Valuation_ZAVA.pdf
```
 
Do not create an Excel file. (`scripts/build_zava_report.py` is only a shared calculation helper
that the PDF script imports.)
 
`build_zava_pdf.py` reuses `compute()` from `build_zava_report.py` (Decimal rounding for Unit Cost,
Dep'n, Rate %, ACV) and draws the layout with reportlab — do not add styling:
 
- **Black except the logo**: all text black, Helvetica (Arial-metric) 8 pt; title 11 pt bold; no fills
or colours anywhere except the ZAVA logo, which uses ZAVA green `#2E8B3E`
- **Every page, top**: small logo badge (green `#2E8B3E` square, white "Z") + **ZAVA Insurance** (small
bold, green `#2E8B3E`) with "Claims Services" beneath (green `#2E8B3E`); centred black bold
**Detail by Reference No.**
- **Header block (page 1), no colons**: `Claim | value | Insurer | ZAVA INSURANCE`,
`Type | value | Adjuster | value`, `(blank) | (blank) | Phone(s) | value`,
`Tax rate | value | E-Mail(s) | value`; then a heavy black rule across the full width
- **10 columns**: Ref | Room | Original Item | Suggested Replacement | Supplier | Qty | RCV |
Rate/% | Dep'n | ACV (no Age, Cond. or Unit Cost columns) — bold, bottom-aligned,
two-line numeric headers where applicable, thin rule under the header row only,
header row **repeated on every page**
- **Rows**: unbordered, top-aligned, wrapped; text columns UPPERCASE; Suggested Replacement is a black
underlined clickable link; currency `$#,##0.00`; Rate % `0.00`; Qty `1`; no total row
- Relative column widths: Ref 5, Room 13, Original Item 33, Suggested Replacement 33, Supplier 15,
Qty 9, RCV 10, Rate % 7, Dep'n 10, ACV 10
- **Page**: landscape Letter; footer with a thin line above it, left
`Printed: Thursday, October 1, 2026 2:31:45 PM`, right `Page X of Y`
 
The script prints JSON with `items`, `totals` (for the chat summary only), `blank_header_fields`
and reconciliation `warnings`.
 
### Step 8: Deliver
Return `Claim_<n>_Valuation_ZAVA.pdf` to the user as a
downloadable file in the chat, then reply with the format below.
 
## Output Format
 
```text
Claim <n> valuation exported → Claim_<n>_Valuation_ZAVA.pdf
Items: <count> | RCV $X | Dep'n $Y | ACV $Z (summary in chat only — the report has no total row)
Blank header fields (not found in Dataverse): <list or "none">
Reconciliation notes: <script warnings, e.g. Ref 19 source ACV 909 vs computed 908.60, or "none">
Columns used: <report field → actual logical name, for each table>
```
 
## Guardrails
- **Read-only**: never create, update or delete Dataverse rows.
- **Never invent data**: any header field or item value not found stays blank; list what was blank.
- **All arithmetic via the script** — never type computed totals or depreciation by hand.
- Brand only as **ZAVA Insurance**; no other insurer names or logos.
- Use only the two configured tables. Columns may be matched by display name as described in Step 2, never guessed.
- Claim data is sensitive: keep the file in the user's workspace/output; do not email or share it unless asked.
 
## Troubleshooting
 
| Problem | Fix |
|---|---|
| No Dataverse connection | Ask the agent owner to add the Microsoft Dataverse tool to the agent |
| No records found although the claim exists | `cca_claimid` may be a lookup column; filter on `_cca_claimid_value` (the related claim's ID) instead of the claim number |
| Depreciation shows 3000% | Source stores percent; the script treats values >1 as percent already — check the column |
| ACV differs from source ACV by < $1 | Source ACV was rounded; the report shows the computed value and notes it |
| `ModuleNotFoundError: reportlab` | `pip install reportlab`, then re-run Step 7 |
| Long URLs wrap mid-word | Expected when no product-name column is mapped; map one to show a readable name |
| Unknown supplier domain | Script falls back to the upper-cased domain name; add it to `SUPPLIERS` in the script |