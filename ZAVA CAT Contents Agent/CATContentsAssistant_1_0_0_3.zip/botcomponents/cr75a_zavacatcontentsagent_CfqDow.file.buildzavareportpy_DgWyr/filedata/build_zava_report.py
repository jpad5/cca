#!/usr/bin/env python3
"""Build the ZAVA Insurance "Detail by Reference No." claim valuation workbook (OPTIONAL output; the primary report is the PDF from build_zava_pdf.py).

Usage:
    python build_zava_report.py --input claim.json --output Claim_8_Valuation_ZAVA.xlsx

Input JSON (already mapped from Dataverse; unknown values must be null/omitted, never invented):
{
  "header": {"claim": "8", "type": null, "tax_rate": null, "adjuster": null,
             "phones": null, "emails": null},
  "items": [
    {"ref": 14, "class": "Bedroom 1", "description": "55-inch television", "brand": "Samsung",
     "replacement_link": "https://www.bestbuy.ca/...", "replacement_name": null,
     "supplier": null, "qty": null, "unit": null, "unit_cost": null,
     "rcv": 1400, "depreciation": 0.3, "acv": 980}
  ]
}
All arithmetic (Dep'n, Rate %, Cash Value, Unit Cost) is computed here, never by hand.
"""
import argparse
import json
import sys
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlparse

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, Side
from openpyxl.worksheet.page import PageMargins

BRAND = "ZAVA Insurance"
TITLE = "Detail by Reference No."
CURRENCY = '"$"#,##0.00'
SUPPLIERS = {
    "bestbuy": "BEST BUY",
    "amazon": "AMAZON",
    "loganandcove": "LOGAN & COVE",
    "walmart": "WALMART",
    "canadiantire": "CANADIAN TIRE",
    "homedepot": "THE HOME DEPOT",
    "costco": "COSTCO",
    "ikea": "IKEA",
    "staples": "STAPLES",
    "thebay": "HUDSON'S BAY",
}
COLUMNS = [  # (header, width) - matches the reference print report
    ("Ref", 5), ("Class", 13), ("Original Item", 33), ("Suggested Replacement", 33),
    ("Supplier", 15), ("Qty", 9), ("Unit\nCost", 10), ("Repl.\nCost", 10),
    ("Dep'n", 10), ("Rate\n%", 7), ("Cash\nValue", 10),
]


def money(x):
    return Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def blank(v):
    return v is None or (isinstance(v, str) and not v.strip())


def supplier_from_link(link):
    if blank(link):
        return None
    host = urlparse(link if "://" in link else "https://" + link).netloc.lower()
    host = host.split(":")[0]
    for prefix in ("www.", "m."):
        if host.startswith(prefix):
            host = host[len(prefix):]
    key = host.split(".")[0]
    return SUPPLIERS.get(key, key.upper() if key else None)


def ref_key(r):
    s = str(r["ref"]) if r["ref"] is not None else ""
    try:
        return (0, float(s), s)
    except ValueError:
        return (1, 0.0, s)


def compute(item):
    """Return a dict of display values for one line item."""
    qty = item.get("qty")
    qty = Decimal(str(qty)) if not blank(qty) else Decimal(1)
    unit = (item.get("unit") or "EACH").upper()
    rcv = item.get("rcv")
    unit_cost = item.get("unit_cost")
    if blank(rcv) and not blank(unit_cost):
        rcv = Decimal(str(unit_cost)) * qty
    repl = money(rcv) if not blank(rcv) else None
    if blank(unit_cost):
        unit_cost = money(repl / qty) if repl is not None and qty else None
    else:
        unit_cost = money(unit_cost)

    rate = item.get("depreciation")
    if not blank(rate):
        rate = Decimal(str(rate))
        if rate > 1:  # supplied as a percentage (30) rather than a fraction (0.3)
            rate = rate / 100
    else:
        rate = None
    dep = money(repl * rate) if repl is not None and rate is not None else None
    if repl is not None and dep is not None:
        cash = repl - dep
    elif not blank(item.get("acv")):
        cash = money(item["acv"])
    else:
        cash = None

    parts = [item.get("description")]
    if not blank(item.get("brand")):
        parts.append(f"- {item['brand']}")
    original = " ".join(p for p in parts if not blank(p))
    link = item.get("replacement_link")
    repl_name = item.get("replacement_name")
    supplier = item.get("supplier") if not blank(item.get("supplier")) else supplier_from_link(link)
    qty_txt = f"{qty.normalize():f} {unit}"
    return {
        "ref": item.get("ref"), "class": item.get("class"), "original": original or None,
        "link": None if blank(link) else link,
        "link_text": repl_name if not blank(repl_name) else (None if blank(link) else link),
        "supplier": supplier, "qty": qty_txt,
        "unit_cost": unit_cost, "repl": repl, "dep": dep,
        "rate": money(rate * 100) if rate is not None else None, "cash": cash,
        "acv_source": item.get("acv"),
    }


def make_logo(path, px=40):
    """Small green (#2E8B3E) square badge with a white 'Z' (generated, no bundled binary)."""
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (px, px), (0x2E, 0x8B, 0x3E))
    d = ImageDraw.Draw(img)
    font = None
    for f in ("DejaVuSans-Bold.ttf", "Arial Bold.ttf", "arialbd.ttf", "LiberationSans-Bold.ttf"):
        try:
            font = ImageFont.truetype(f, int(px * 0.7))
            break
        except OSError:
            continue
    font = font or ImageFont.load_default()
    box = d.textbbox((0, 0), "Z", font=font)
    w, h = box[2] - box[0], box[3] - box[1]
    d.text(((px - w) / 2 - box[0], (px - h) / 2 - box[1]), "Z", fill="white", font=font)
    img.save(path)
    return path


def up(v):
    return v.upper() if isinstance(v, str) else v


def build(data, out_path):
    import os
    import tempfile
    from openpyxl.cell.rich_text import CellRichText, TextBlock
    from openpyxl.cell.text import InlineFont
    from openpyxl.drawing.image import Image as XLImage

    header = data.get("header", {}) or {}
    rows = sorted((compute(i) for i in data.get("items", [])), key=ref_key)

    wb = Workbook()
    ws = wb.active
    ws.title = "Detail by Reference No"
    ws.sheet_view.showGridLines = False
    ncol = len(COLUMNS)
    last = ws.cell(row=1, column=ncol).column_letter
    for i, (_, w) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w

    bold = Font(name="Arial", bold=True, size=8, color="000000")
    norm = Font(name="Arial", size=8, color="000000")
    medium = Side(style="medium", color="000000")
    thin = Side(style="thin", color="000000")

    # Row 1: logo badge + "ZAVA Insurance" / "Claims Services", centred bold title
    ws.row_dimensions[1].height = 32
    logo_path = make_logo(os.path.join(tempfile.mkdtemp(), "zava_logo.png"))
    logo = XLImage(logo_path)
    logo.width = logo.height = 30
    ws.add_image(logo, "A1")
    brand = CellRichText(
        TextBlock(InlineFont(rFont="Arial", sz=8, b=True, color="2E8B3E"), BRAND),
        TextBlock(InlineFont(rFont="Arial", sz=7, color="2E8B3E"), "\nClaims Services"),
    )
    ws["B1"] = brand
    ws["B1"].alignment = Alignment(wrap_text=True, vertical="center")
    ws.merge_cells("B1:C1")
    ws["D1"] = TITLE
    ws["D1"].font = Font(name="Arial", bold=True, size=11, color="000000")
    ws["D1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.merge_cells(f"D1:{ws.cell(row=1, column=ncol - 3).column_letter}1")

    def val(v):
        return "" if blank(v) else str(v)

    tax = header.get("tax_rate")
    if not blank(tax):
        try:
            t = Decimal(str(tax))
            tax = f"{money(t * 100 if t <= 1 else t)}%"
        except Exception:
            pass
    block = [
        ("Claim", header.get("claim"), "Insurer", BRAND.upper()),
        ("Type", header.get("type"), "Adjuster", header.get("adjuster")),
        ("", None, "Phone(s)", header.get("phones")),
        ("Tax rate", tax, "E-Mail(s)", header.get("emails")),
    ]
    top = 3
    for n, (l1, v1, l2, v2) in enumerate(block):
        r = top + n
        ws.cell(row=r, column=1, value=l1 or None).font = bold
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=2)
        c = ws.cell(row=r, column=3, value=val(v1) or None)
        c.font = norm
        ws.merge_cells(start_row=r, start_column=3, end_row=r, end_column=5)
        ws.cell(row=r, column=8, value=l2).font = bold
        c = ws.cell(row=r, column=9, value=val(v2) or None)
        c.font = norm
        ws.merge_cells(start_row=r, start_column=9, end_row=r, end_column=ncol)
    hb = top + len(block) - 1
    for col in range(1, ncol + 1):
        ws.cell(row=hb, column=col).border = Border(bottom=medium)

    # Table header: bold, bottom-aligned, thin rule beneath only
    hr = hb + 2
    for i, (h, _) in enumerate(COLUMNS, start=1):
        c = ws.cell(row=hr, column=i, value=h)
        c.font = bold
        c.alignment = Alignment(wrap_text=True, vertical="bottom",
                                horizontal="left" if i <= 6 else "right")
        c.border = Border(bottom=thin)
    ws.row_dimensions[hr].height = 24
    ws.print_title_rows = f"{hr}:{hr}"

    r = hr + 1
    tot = {"repl": Decimal(0), "dep": Decimal(0), "cash": Decimal(0)}
    for row in rows:
        vals = [row["ref"], up(row["class"]), up(row["original"]), up(row["link_text"]) if row["link_text"] != row["link"] else row["link_text"],
                up(row["supplier"]), up(row["qty"]), row["unit_cost"], row["repl"],
                row["dep"], row["rate"], row["cash"]]
        for i, v in enumerate(vals, start=1):
            if isinstance(v, Decimal):
                v = float(v)
            c = ws.cell(row=r, column=i, value=v)
            c.font = norm
            c.alignment = Alignment(wrap_text=True, vertical="top",
                                    horizontal="left" if i <= 6 else "right")
            if i in (7, 8, 9, 11):
                c.number_format = CURRENCY
            if i == 10:
                c.number_format = "0.00"
        if row["link"]:
            c = ws.cell(row=r, column=4)
            c.hyperlink = row["link"]
            c.font = Font(name="Arial", size=8, underline="single", color="000000")
        for k in tot:
            if row[k] is not None:
                tot[k] += row[k]
        r += 1
    last_row = r - 1

    # Page setup: landscape Letter, 1 page wide, repeat header row, print footer
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_LETTER
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = PageMargins(left=0.4, right=0.4, top=0.5, bottom=0.6)
    ws.print_area = f"A1:{last}{last_row}"
    ws.oddFooter.left.text = "Printed: &D &T"
    ws.oddFooter.left.font = "Arial,Regular"
    ws.oddFooter.left.size = 8
    ws.oddFooter.right.text = "Page &P of &N"
    ws.oddFooter.right.font = "Arial,Regular"
    ws.oddFooter.right.size = 8

    wb.save(out_path)

    # Reconciliation: computed Cash Value vs source ACV (source is often rounded)
    warnings = []
    for row in rows:
        if not blank(row["acv_source"]) and row["cash"] is not None:
            if abs(row["cash"] - money(row["acv_source"])) >= 1:
                warnings.append(
                    f"Ref {row['ref']}: computed cash value {row['cash']} vs source ACV {row['acv_source']}")
    return {"output": out_path, "items": len(rows),
            "totals": {k: str(v) for k, v in tot.items()}, "warnings": warnings}


def main():
    ap = argparse.ArgumentParser(description="Build the ZAVA Insurance claim valuation workbook.")
    ap.add_argument("--input", required=True, help="Mapped claim JSON")
    ap.add_argument("--output", required=True, help="Destination .xlsx path")
    a = ap.parse_args()
    with open(a.input, encoding="utf-8") as f:
        data = json.load(f)
    if not data.get("items"):
        print(json.dumps({"error": "No line items in input"}))
        sys.exit(1)
    print(json.dumps(build(data, a.output), indent=2))


if __name__ == "__main__":
    main()
