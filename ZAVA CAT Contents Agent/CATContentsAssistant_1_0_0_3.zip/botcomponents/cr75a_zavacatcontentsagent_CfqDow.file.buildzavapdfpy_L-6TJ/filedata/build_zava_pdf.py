#!/usr/bin/env python3
"""Build the ZAVA Insurance "Detail by Reference No." claim valuation report as a PDF (primary output).

Usage:
    python build_zava_pdf.py --input claim.json --output Claim_8_Valuation_ZAVA.pdf [--xlsx]

Input JSON is the same mapped shape documented in build_zava_report.py (null = not found, never invented).
Calculations (Unit Cost, Dep'n, Rate %, Cash Value) reuse compute() from build_zava_report.py.
--xlsx additionally writes an Excel version next to the PDF (only when the user asks for one).
"""
import argparse
import json
import os
import sys
from datetime import datetime
from decimal import Decimal
from xml.sax.saxutils import escape

from reportlab.lib.colors import black, HexColor, white
from reportlab.lib.enums import TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.platypus import LongTable, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from build_zava_report import BRAND, TITLE, blank, compute, money, ref_key  # noqa: E402

FONT, BOLD = "Helvetica", "Helvetica-Bold"  # metric-compatible with Arial
SIZE = 8
ZAVA_GREEN = HexColor("#2E8B3E")  # logo badge + logo text only; everything else black
PAGE = landscape(letter)
MARGIN_X = 0.4 * inch
TOP_BAND = 0.95 * inch      # space reserved for logo/title drawn on every page
BOTTOM_BAND = 0.65 * inch   # space reserved for footer
COLUMNS = [  # (header, relative width, numeric)
    ("Ref", 5, False), ("Class", 13, False), ("Original Item", 33, False),
    ("Suggested Replacement", 33, False), ("Supplier", 15, False), ("Qty", 9, False),
    ("Unit<br/>Cost", 10, True), ("Repl.<br/>Cost", 10, True),
    ("Dep'n", 10, True), ("Rate<br/>%", 7, True), ("Cash<br/>Value", 10, True),
]

S_TXT = ParagraphStyle("t", fontName=FONT, fontSize=SIZE, leading=SIZE + 1.5, alignment=TA_LEFT,
                       splitLongWords=1, textColor=black)
S_NUM = ParagraphStyle("n", parent=S_TXT, alignment=TA_RIGHT)
S_HDR = ParagraphStyle("h", parent=S_TXT, fontName=BOLD)
S_HDR_NUM = ParagraphStyle("hn", parent=S_HDR, alignment=TA_RIGHT)


def p(text, style=S_TXT):
    return Paragraph("" if blank(text) else escape(str(text)), style)


def cur(v):
    return "" if v is None else f"${v:,.2f}"


def dec2(v):
    if blank(v):
        return ""
    try:
        return f"{Decimal(str(v)):.2f}"
    except Exception:
        return str(v)


def up(v):
    return v.upper() if isinstance(v, str) else v


def printed_stamp(now=None):
    now = now or datetime.now()
    hour = now.strftime("%I").lstrip("0") or "12"
    return f"{now:%A, %B} {now.day}, {now:%Y} {hour}:{now:%M:%S %p}"


class NumberedCanvas(rl_canvas.Canvas):
    """Two-pass canvas so every page can print 'Page X of Y' plus the brand band."""

    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)
        self._saved = []

    def showPage(self):
        self._saved.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        total = len(self._saved)
        for state in self._saved:
            self.__dict__.update(state)
            self.draw_chrome(total)
            super().showPage()
        super().save()

    def draw_chrome(self, total):
        w, h = PAGE
        top = h - 0.45 * inch
        # Logo badge: dark square, white Z
        s = 0.34 * inch
        self.setFillColor(ZAVA_GREEN)
        self.rect(MARGIN_X, top - s, s, s, stroke=0, fill=1)
        self.setFillColor(white)
        self.setFont(BOLD, 15)
        self.drawCentredString(MARGIN_X + s / 2, top - s + 0.09 * inch, "Z")
        self.setFillColor(ZAVA_GREEN)
        self.setFont(BOLD, SIZE)
        self.drawString(MARGIN_X + s + 6, top - 0.13 * inch, BRAND)
        self.setFont(FONT, SIZE - 1)
        self.drawString(MARGIN_X + s + 6, top - 0.27 * inch, "Claims Services")
        self.setFillColor(black)
        # Title
        self.setFont(BOLD, 11)
        self.drawCentredString(w / 2, top - 0.2 * inch, TITLE)
        # Footer
        y = 0.45 * inch
        self.setStrokeColor(black)
        self.setLineWidth(0.5)
        self.line(MARGIN_X, y + 11, w - MARGIN_X, y + 11)
        self.setFont(FONT, SIZE)
        self.drawString(MARGIN_X, y, f"Printed: {self._printed}")
        self.drawRightString(w - MARGIN_X, y, f"Page {self._pageNumber} of {total}")


def build_pdf(data, out_path):
    header = data.get("header", {}) or {}
    rows = sorted((compute(i) for i in data.get("items", [])), key=ref_key)
    width = PAGE[0] - 2 * MARGIN_X
    rel = sum(c[1] for c in COLUMNS)
    col_w = [width * c[1] / rel for c in COLUMNS]

    # Header block (no colons), heavy rule beneath, full width
    tax = header.get("tax_rate")
    if not blank(tax):
        try:
            t = Decimal(str(tax))
            tax = f"{money(t * 100 if t <= 1 else t)}%"
        except Exception:
            pass
    hb = [
        ("Claim", header.get("claim"), "Insurer", BRAND.upper()),
        ("Type", header.get("type"), "Adjuster", header.get("adjuster")),
        ("", None, "Phone(s)", header.get("phones")),
        ("Tax rate", tax, "E-Mail(s)", header.get("emails")),
    ]
    hb_data = [[p(a, S_HDR), p(b), p(c, S_HDR), p(d)] for a, b, c, d in hb]
    left_w = sum(col_w[:2])
    hb_w = [left_w, width * 0.5 - left_w, 0.9 * inch, width * 0.5 - 0.9 * inch]
    hb_tbl = Table(hb_data, colWidths=hb_w)
    hb_tbl.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 2),
        ("TOPPADDING", (0, 0), (-1, -1), 1), ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING", (0, -1), (-1, -1), 5),
        ("LINEBELOW", (0, -1), (-1, -1), 1.5, black),
    ]))

    # Line-item table
    head = [Paragraph(h, S_HDR_NUM if num else S_HDR) for h, _, num in COLUMNS]
    body = [head]
    for r in rows:
        link_cell = p(None)
        if r["link"]:
            txt = r["link_text"] if r["link_text"] == r["link"] else up(r["link_text"])
            link_cell = Paragraph(
                f'<link href="{escape(r["link"], {chr(34): "&quot;"})}" color="black"><u>{escape(str(txt))}</u></link>',
                S_TXT)
        body.append([
            p(r["ref"]), p(up(r["class"])), p(up(r["original"])), link_cell, p(up(r["supplier"])),
            p(up(r["qty"])), p(cur(r["unit_cost"]), S_NUM), p(cur(r["repl"]), S_NUM),
            p(cur(r["dep"]), S_NUM),
            p(dec2(r["rate"]), S_NUM), p(cur(r["cash"]), S_NUM),
        ])
    tbl = LongTable(body, colWidths=col_w, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, 0), "BOTTOM"),
        ("VALIGN", (0, 1), (-1, -1), "TOP"),
        ("LINEBELOW", (0, 0), (-1, 0), 0.5, black),
        ("LEFTPADDING", (0, 0), (-1, -1), 2), ("RIGHTPADDING", (0, 0), (-1, -1), 2),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))

    printed = printed_stamp()

    class _Canvas(NumberedCanvas):
        _printed = printed

    doc = SimpleDocTemplate(out_path, pagesize=PAGE, leftMargin=MARGIN_X, rightMargin=MARGIN_X,
                            topMargin=TOP_BAND, bottomMargin=BOTTOM_BAND,
                            title=f"{TITLE} - Claim {header.get('claim') or ''}".strip(), author=BRAND)
    doc.build([hb_tbl, Spacer(1, 10), tbl], canvasmaker=_Canvas)

    tot = {k: sum((r[k] for r in rows if r[k] is not None), Decimal(0)) for k in ("repl", "dep", "cash")}
    warnings = [f"Ref {r['ref']}: computed cash value {r['cash']} vs source ACV {r['acv_source']}"
                for r in rows if not blank(r["acv_source"]) and r["cash"] is not None
                and abs(r["cash"] - money(r["acv_source"])) >= 1]
    blanks = [k for k in ("claim", "type", "tax_rate", "adjuster", "phones", "emails") if blank(header.get(k))]
    return {"pdf": out_path, "items": len(rows), "totals": {k: str(v) for k, v in tot.items()},
            "blank_header_fields": blanks, "warnings": warnings}


def main():
    ap = argparse.ArgumentParser(description="Build the ZAVA Insurance claim valuation PDF.")
    ap.add_argument("--input", required=True, help="Mapped claim JSON")
    ap.add_argument("--output", required=True, help="Destination .pdf path")
    ap.add_argument("--xlsx", action="store_true", help="Also write an optional Excel version")
    a = ap.parse_args()
    with open(a.input, encoding="utf-8") as f:
        data = json.load(f)
    if not data.get("items"):
        print(json.dumps({"error": "No line items in input"}))
        sys.exit(1)
    result = build_pdf(data, a.output)
    if a.xlsx:
        from build_zava_report import build as build_xlsx
        result["xlsx"] = build_xlsx(data, os.path.splitext(a.output)[0] + ".xlsx")["output"]
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
